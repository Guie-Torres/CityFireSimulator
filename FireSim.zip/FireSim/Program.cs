﻿using System;

namespace MestoApp
{
    class Program
    {
        static void Main(string[] args)
        {
            City city = new City(3);

            city.RandomCity();
            city.DrawMap();

            Console.WriteLine("SimFire : Input the X position");
            int x = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("SimFire : Input the Y position");
            int y = Convert.ToInt32(Console.ReadLine());

            city.SimFire(x, y);

            Console.WriteLine("City after fire :");

            city.DrawMap();
        }
    }

    class Building
    {
        public string Name { get; set; }

        public int X { get; set; }
        public int Y { get; set; }

        public Material Material { get; set; }

        public int NumOfFloors { get; set; }

        public int Value { get; set; }
        public Building() { }

        public Building(string name, Material material, int numOfFloors, int value)
        {
            this.Name = name;

            this.Material = material;

            this.NumOfFloors = numOfFloors;

            this.Value = value;
        }

        public static Building Random( int x, int y)
        {
            Building b = new Building();
            Random rnd = new Random();

            //default owner name
            b.Name = "Pepa";

            b.NumOfFloors = rnd.Next(5);
            b.Value = rnd.Next(500);
            b.X = x;
            b.Y = y;

            if (rnd.Next(4) == 2)
                return null;
            else
                b.Material = (Material)rnd.Next(3);

            return b;
        }

        public void Vypis()
        {
            Console.WriteLine((int)this.Material);
        }
    }

    enum Material
    {
        Wood = 0, 
        Concreate = 1,
        Brick = 2,
        Fire = 3
    }

    class City
    {
        public Building[,] Buildings { get; set; }
        public int Size { get; set; }

        public City() { }

        public City(int size)
        {
            this.Size = size;

            this.Buildings = new Building [size, size];
        }

        public void Add(int posX, int posY, Building building)
        {
            if (this.Buildings[posX, posY] != null)
                return;

            this.Buildings[posX, posY] = building;
        }

        public void Update(int posX, int posY, string name, int numOfFloors, int value, Material material)
        {
            if (this.Buildings[posX, posY] == null)
                return;

            Building building = Buildings[posX, posY];

            building.Name = name;
            building.NumOfFloors = numOfFloors;
            building.Value = value;
            building.Material = material;
            building.X = posX;
            building.Y = posY;
        }

        public void Remove(int posX, int posY)
        {
            if (Buildings[posX, posY] == null)
                return;

            Buildings[posX, posY] = null;
        }

        public void List()
        {
            for(int i = 0; i < Size; i++)
            {
                for (int o = 0; o < Size; o++)
                {
                    Building building = Buildings[i, o];

                    if (building != null)
                    {
                        Console.WriteLine(string.Format("Number of floors : {0}, Name of owner : {1}, Value : {2}, Material : {3}", building.NumOfFloors, building.Name, building.Value, building.Material));
                    }
                }
            }

        }

        public void DrawMap()
        {
            for(int i = 0; i < Size; i++)
            {
                for(int o = 0; o < Size; o++)
                {
                    Building building = Buildings[o, i];

                    if (building == null)
                        Console.Write("-");
                    else
                        Console.Write((int)building.Material);
                }

                Console.WriteLine("");
            }
        }

        public void RandomCity()
        {
            for(int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    Add(j, i, Building.Random(j, i));
                }
            }
        }

        public void Floors()
        {
            int totalNumberOfFloors = 0;

            foreach(Building building in Buildings)
            {
                if(building != null)
                    totalNumberOfFloors += building.NumOfFloors;
            }

            Console.WriteLine($"Total amount of floors : {totalNumberOfFloors}");
        }

        public void Value()
        {
            int totalValue = 0;

            foreach (Building building in Buildings)
            {
                if (building != null)
                    totalValue += building.Value;
            }

            Console.WriteLine($"Total value of the city : {totalValue}");
        }

        public void Count(string name)
        {
            int numOfBuildings = 0;

            foreach (Building building in Buildings)
            {
                if (building != null && building.Name == name)
                    numOfBuildings++;
            }

            if(numOfBuildings == 0)
                Console.WriteLine($"{name} owns {numOfBuildings} building");
            else
                Console.WriteLine($"{name} owns {numOfBuildings} buildings");
        }      

        public void SimFire(int x, int y)
        {
            if(x < 0 || y < 0 || x >= Size || y >= Size || Buildings[x, y] == null || Buildings[x, y].Material != Material.Wood) return;

            List<Building> buildings = new();
            buildings.Add(Buildings[x, y]);
            bool spread = true;

            while(spread){
                spread = false;
                List<Building> _buildings = new();

                foreach(Building building in buildings){
                    building.Material = Material.Fire;
                     for(int i = 0; i < 4; i++){
                        int currentX = building.X;
                        int currentY = building.Y;

                         switch(i){
                             case 0: currentX -= 1; break;
                             case 1: currentX += 1; break;
                             case 2: currentY -= 1; break;
                             case 3: currentY += 1; break;
                          }

                         if(currentX < 0 || currentY < 0 || currentX >= Size || currentY >= Size || Buildings[currentX, currentY] == null || Buildings[currentX, currentY].Material != Material.Wood) continue;

                            spread = true;
                           _buildings.Add(Buildings[currentX, currentY]);
                      }
               }

               buildings = new List<Building>(_buildings);
            }

        }
    }
}

